#Variables
<#
        _global = "Global Variable Space (See Script)"
        _global = Logical Form Object (Reference to self)
                Note:
                        This gets defined inside an action of a UIElement ie a button
        self = Window UI Form
                Note:
                        Must be declared inside the xaml file
                Example:
                        $self = $that.Window

        _global.Window = Window UI Form
        _global.jobs = List of Threads
#>


<#
        Create a Global Variable Space
#>
$Global:_global = [hashtable]::Synchronized(@{})


#$FilePath = split-path $SCRIPT:MyInvocation.MyCommand.Path -parent
#$File = $MyInvocation.MyCommand.Path

[xml]$_v = get-content "$(split-path $File -parent)\Settings.xml"
#$_global.PATH = @{}
#Define File Paths

$_obj = $_global
$_global.ZipFile = $ZipFile
foreach ($i in $_v.MAIN.PATHOLD.ChildNodes) {
	switch($i.TYPE) {
		"FILE" {
			$_obj[$i.NAME] = $File
		}
		"RELATIVE" {
			[string]$_obj[$i.NAME] = $(split-path $File -parent) + "\"+ $i.'#text'
		}
		default {
			[string]$_obj[$i.NAME] = $i.'#text'
		}
	}
}

$_global.PATHS = @{}
$_obj = $_global.PATHS
foreach ($i in $_v.MAIN.PATH.ChildNodes) {
	switch($i.TYPE) {
		"FILE" {
			$_obj[$i.NAME] = $File
		}
		"RELATIVE" {
			[string]$_obj[$i.NAME] = $(split-path $File -parent) + "\"+ $i.'#text'
		}
		default {
			[string]$_obj[$i.NAME] = $i.'#text'
		}
	}
}


#Note:
#Todo: Implement Threading
#Not all variables that are defined are used.
#Global Scope is not actually Global. You have to push the variable into the thread.
$v = $_global.File
$_global.DEBUG = $DEBUG
#$_global.SDE = [hashtable]::Synchronized(@{})
